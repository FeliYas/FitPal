class Usuario {
  constructor(nombre, apellido, edad, telefono, email, id) {
    this.nombre = nombre;
    this.apellido = apellido;
    this.edad = edad;
    this.telefono = telefono;
    this.email = email;
    this.id = id;
}